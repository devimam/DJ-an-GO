class PathConverter:
	#define your path converter regular expression here
	#let's assime our path is of the form 
	# form: 'z-1234-id-123455'
	#let's write it's regular expression
	regex="z-[0-9]{4}-id-[0-9]{6}"
	
	
	#we need to define two methods
	def to_python(self, value):
		#this method will convert the matched string to python types
		#let's assume the python equivalent of this converter
		# is a list of two integers containing the parts 1234 and 123455 only
		l=value.split('-')
		return [l[1],l[3]]
		
		
	#we need to define another method named to_url
	def to_url(self, value):
		#this method will convert the provided parameters from python 
		# to this url pattern
		#let's assume we will use parameter from python in the form
		#form: '1234-123455'
		#so we need to return this kind of url 'z-1234-id-123455'
		l=value.split('-')
		
		return 'z-%04d-id-%06d' % ( int(l[0]), int(l[1]) )