from django.urls import path, register_converter
from . import views

from . import pathconverter

register_converter(pathconverter.PathConverter, 'pconv')

#remaining portion after 'demoapp/' will be matched here
urlpatterns=[
	#calling homeview fn
	path('', views.homeview, name='homeview'),
	
	#new pattern with pattern name
	path('newpattern/', views.newpattern, name='patname'),
	
	#using our own path converter
	path('<int:var1>/<pconv:var2>/', views.pconv, name='pconv'),
	
	
	
]