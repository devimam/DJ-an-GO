from django.shortcuts import render

# Create your views here.

#our homeview fn
def homeview(request):
	return render(request, 'home.html')
	
def newpattern(request):
	return render(request, 'newpattern.html')
	
def pconv(request, var1, var2):
	context={
		'var1' : var1,
		#remember our var2 is a python list 
		#according to our to_python conversion code
		'var2_0' : var2[0],
		'var2_1' : var2[1],
	}
	
	return render(request, 'pconv.html', context)