from django.shortcuts import render

# Create your views here.


def mainview(request, key):
	context={
		'data': 'from Main page, with key='+key,
	}
	#rendering to main.html with context data
	return render(request,'main.html',context)
	
def mainpageview(request, key):
	context={
		'data': 'from Main page view, with key='+key,
	}
	#rendering to main.html with context data
	return render(request,'main.html',context)