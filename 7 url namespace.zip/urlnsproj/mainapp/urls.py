from django.urls import path, include

from . import views

#declaring application namespace
app_name='mainapp'

#rest of the URL after mainapp/ will be matched here
urlpatterns=[
	path('', views.mainview, name='mainurl'),
	
	#myurl will forward us to the page mainpage/
	path('mainpage/', views.mainpageview, name='myurl'),
]