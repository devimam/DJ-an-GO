from django.urls import path

from . import views

#defining childapp namespace
app_name='childapp'

#rest of the url after 'mainapp/childapp/' will be matched here
urlpatterns=[
	#calling childview 
	path('', views.childview, name='childurl'),
	
	#let's name this as the same as 'myurl'
	path('childpage/', views.childpageview, name='myurl'),
]