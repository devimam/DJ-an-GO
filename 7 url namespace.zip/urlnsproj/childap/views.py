from django.shortcuts import render

# Create your views here.

def childview(request, key):
	context={
		'data': 'from Child page, key='+key,
	}
	return render(request, 'childhome.html', context)
	
def childpageview(request, key):
	context={
		'data': 'from Child page view, key='+key,
	}
	return render(request, 'childhome.html', context)