from django import forms


class MyForm(forms.Form):
	#MyForm is a subclass of forms.Form object 
	#let's create the DateTimeField object field
	#let's set some parameters of this object 
	dt_field=forms.DateTimeField(\
		required=True,\
		label='Enter the date time',\
		label_suffix=':',\
		initial=None,\
		help_text='2020-01-11 08:10:20',\
		error_messages={'required':'Can\'t be empty', 'invalid': 'Invalid date format'},\
		disabled=False,\
		input_formats=['%Y-%m-%d %H:%M:%S'],\
	)