from django.shortcuts import render

from .myform import MyForm
# Create your views here.

def mainview(request):
	f=MyForm()
	#rendering the home.html template 
	#sending this form to the template 
	# for generating the html codes
	return render(request,'home.html', {'form': f})
	
def showview(request):
	#creating a bound form object
	rec_f=MyForm(request.POST)
	
	#obtaining the bound field from the form
	b_f=rec_f['dt_field']
	
	#ok let's show some properties of this boundform
	dct={
		'auto_id': b_f.auto_id,
		'data': b_f.data,
		'errors': b_f.errors,
		'field': b_f.field,
		'form': b_f.form,
		'help_text': b_f.help_text,
		'html_name': b_f.html_name,
		'id_for_label': b_f.id_for_label,
		'is_hidden': b_f.is_hidden,
		'label': b_f.label,
		'name': b_f.name,
	}
	
	#let's send this data to the template page
	return render(request, 'show.html', {'data': dct})
	