from django.urls import path
from . import views

urlpatterns=[
	#it will match the remaining portion of the url after 'demoapp/'
	path('', views.myview, name='myview'),
]