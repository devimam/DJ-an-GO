from django.shortcuts import render

# Create your views here.


def myview(request):
	#perform validation here
	#perform database operations here
	#access data models from here
	#call django form from here etc
	return render(request,'home.html')