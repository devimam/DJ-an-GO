from django.urls import path

from . import views

#rest of the urls after 'mainapp/' will be matched here
urlpatterns=[
	#calling mainview from here 
	path('', views.mainview, name='mainurl'),
	
	#for showing the form data
	path('showdata/', views.showview, name='showview'),
]