from django.shortcuts import render

from .MyForm import MyForm 
# Create your views here.

def mainview(request):
	f=MyForm()
	#rendering the home.html from mainview 
	#sending this form to the template to generate the html
	#this form will create <input type='text' ... > field
	return render(request, 'home.html',{'form': f})
	
def showview(request):
	#initializing the form with received data
	rec_f=MyForm(request.POST)
	
	#To extract the field from this form we will use 
	#BoundField
	#let's extract the BoundField from this form 
	b_f=rec_f['txt_field'] #use name of the field 
	
	#let's access some methods and attributes of this field 
	dct={
		'auto_id' : b_f.auto_id,
		'data' : b_f.data,
		'errors': b_f.errors,
		'field': b_f.field,
		'form': b_f.form,
		'help_text': b_f.help_text,
		'html_name': b_f.html_name,
		'id_for_label': b_f.id_for_label,
		'is_hidden': b_f.is_hidden,
		'label': b_f.label,
		'name': b_f.name,
	}
	
	#let's send the data to template and show them
	return render(request, 'show.html', {'data': dct})