from django import forms

#MyForm is a subclass of forms module
class MyForm(forms.Form):
	#using some major parameters of CharField 
	txt_field=forms.CharField(\
	required=True,\
	label="Enter Your First Name",\
	label_suffix=">>",\
	initial="",\
	help_text="enter full name",\
	error_messages={'required':'Name can\'t be empty', 'max_length':'Enter at most 50 characters','min_length':'Enter at least 5 characters' },\
	disabled=False,\
	max_length=50,\
	min_length=5,\
	strip=True,\
	empty_value='None',\
	)