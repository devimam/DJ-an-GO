from django import forms

from django.core import validators

class MyForm(forms.Form):
	#charfield having slug validator
	slug_field=forms.CharField(required=False, validators=[validators.validate_slug])
	ipv4_field=forms.CharField(required=False, validators=[validators.validate_ipv4_address])
	intlist_field=forms.CharField(required=False, validators=[validators.validate_comma_separated_integer_list])
	email_field=forms.CharField(required=False, validators=[validators.validate_email])
	
	#this RegexValidator contains some attributes 
	#let's set the major ones
	#suppose we will match strings that starts with F-then 4 digits
	#for example F-0123, let's write the regular expression
	userid_field=forms.CharField(required=False, validators=[validators.RegexValidator(regex="^F-[0-9]{9}$", code='invalid_id', message='Invalid User Id Entry')])
	
	
	#let's use an EmailValidator that uses user defined email domains 
	#forexample, abc@mydomain
	#let's whitelist that domain 
	myemail_field=forms.CharField(required=False, validators=[validators.EmailValidator(whitelist=['mydomain'])])
	
	#let's create  a maxlengthvalidator for the charfield
	maxlen_field=forms.CharField(required=False, validators=[validators.MaxLengthValidator(limit_value=5)])
	
	#let's create an URL validator that only accepts https and ftps schemes
	myurl_field=forms.CharField(required=False, validators=[validators.URLValidator(schemes=['https','ftps'])])
	
	