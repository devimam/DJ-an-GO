from django.shortcuts import render

from .myform import MyForm
# Create your views here.

def mainview(request):
	f=MyForm()
	#from mainview rendering home.html 
	return render(request,'home.html',{'form':f})
	
def showview(request):
	#received data wil be here
	r_f=MyForm(request.POST)
	
	#let's show the errors and data 
	#first saving them in a dictionary
	
	dct={
		'slug_field_error': r_f['slug_field'].errors,
		'slug_field_data': r_f['slug_field'].data,
		
		'ipv4_field_error': r_f['ipv4_field'].errors,
		'ipv4_field_data': r_f['ipv4_field'].data,
		
		'intlist_field_error': r_f['intlist_field'].errors,
		'intlist_field_data': r_f['intlist_field'].data,
		
		
		'userid_field_error': r_f['userid_field'].errors,
		'userid_field_data': r_f['userid_field'].data,
		
		'email_field_error': r_f['email_field'].errors,
		'email_field_data': r_f['email_field'].data,
		
		'myemail_field_error': r_f['myemail_field'].errors,
		'myemail_field_data': r_f['myemail_field'].data,
		
		'maxlen_field_error': r_f['maxlen_field'].errors,
		'maxlen_field_data': r_f['maxlen_field'].data,
		
		'myurl_field_error': r_f['myurl_field'].errors,
		'myurl_field_data': r_f['myurl_field'].data,
		
		
	}
	
	return render(request, 'show.html', {'data': dct})