from django.urls import path

from . import views

#rest of the urls after 'mainapp/' will be matched here
urlpatterns=[
	#calling mainview fn
	path('', views.mainview, name='mainurl'),
	
	#showing data
	path('show/', views.showview, name='showurl'),
]