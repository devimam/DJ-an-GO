from django.shortcuts import render

# Create your views here.

def childview(request):
	context={
		'data': 'from Child view page',
	}
	return render(request, 'childhome.html', context)