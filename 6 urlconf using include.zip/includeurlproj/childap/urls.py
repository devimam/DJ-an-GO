from django.urls import path

from . import views

#rest of the url after 'mainapp/childapp/' will be matched here
urlpatterns=[
	#calling childview 
	path('', views.childview, name='childview'),
]