from django.shortcuts import render

# Create your views here.


def mainview(request):
	context={
		'data': 'from Main page',
	}
	#rendering to main.html with context data
	return render(request,'main.html',context)
	
def pathview(request, v):
	context={
		'data' : 'path view page, v='+v,
	}
	return render(request, 'main.html', context)