from django.urls import path, include

from . import views

subpath=[
	path('path1/', views.pathview, {'v':'path1'} ,name='path1'),
	path('path2/', views.pathview, {'v':'path2'} ,name='path2'),
	path('path3/', views.pathview, {'v':'path3'} ,name='path3'),
	path('path4/', views.pathview, {'v':'path4'} ,name='path4'),
]

#rest of the URL after mainapp/ will be matched here
urlpatterns=[
	path('', views.mainview, name='mainview'),
	
	#includign the childap url configs
	path('childapp/', include('childap.urls') ),
	
	#let's include this list of urlpatterns here
	path('mypath/', include(subpath)),
	#simple
]