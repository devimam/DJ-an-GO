from django.urls import path

from . import views

#rest of the urls after 'mainapp/' will be matched here
urlpatterns=[
	#calling the myview 
	path('', views.myview, name='myview'), 
]