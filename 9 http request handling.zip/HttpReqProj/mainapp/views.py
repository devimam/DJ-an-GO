from django.shortcuts import render

# Create your views here.

def myview(request):
	#django automatically send the request object to the view 
	#this http reqeuest object 
	#contains several attributes and methods
	
	#here I am illustrating some major ones
	
	#let's save the request object data in a dictionary
	
	dct={
		#to get the request scheme, http/https
		'Scheme': request.scheme,
		
		#to get the request method, GET/POST
		'Method': request.method,
		
		#to see the whole request body
		#'Request_Body': request.body,
		
		#to get the requested url path
		#this path will exclude the scheme and domain partition
		'Request_Path': request.path,
		
		#to get the content-type of request body 
		'Request_Content_Type': request.content_type,
		
		#to receive the GET parameters with the request 
		#both variable and values 
		#it is a dictionary like object named QueryDict
		'GET_Data': request.GET,
		
		
		#to receive the POST parameters with the request
		#both parameter and values
		#it is also a dict like object named QueryDict 
		'POST_Data' : request.POST,
		
		#to receive the incoming cookies with this request
		#also a dict like object QueryDict 
		'Cookies': request.COOKIES,
		
		#we can also access any http request headers using
		#the META attribute , it is mainly a dictionary 
		#let's access some of the headers 
		'http_accept' : request.META['HTTP_ACCEPT'],
		'http_host': request.META['HTTP_HOST'],
		'query_string': request.META['QUERY_STRING'],
		'remote_addr': request.META['REMOTE_ADDR'],
		'remote_host': request.META['REMOTE_HOST'],
		'server_name': request.META['SERVER_NAME'],
		'server_port': request.META['SERVER_PORT'],
		
		
	}
	
	#let's send this dictionary to the template for view 
	context={
		'data': dct,
	}
	
	#checking whether the file is received or not 
	if request.FILES:
		uplfile=request.FILES['myfile']
		context['filename']=uplfile.name
		context['filesize']=uplfile.size
		context['contenttype']=uplfile.content_type
		context['filedata']=uplfile.read()
		context['filecharset']=uplfile.charset
	

	#rendering the home.html template
	return render(request, 'home.html', context)