from django.shortcuts import render

from .myform import MyForm

# Create your views here.

def myview(request):
	f=MyForm()
	#rendering the home.html template
	#sending the form object to template
	return render(request,'home.html',{'form': f})
	
	
def showview(request):
	f=MyForm(request.POST)
	
	b_f=f['b_field']
	#here b_f is a BoundField object representing that BooleanField
	#let's show the bound field attributes
	
	dct={
		'auto_id': b_f.auto_id, #html id 
		'data': b_f.data, #the data of the field 
		'errors': b_f.errors, #errors of that field if generated
		'field': b_f.field, #the name of the field represented by this boundfield for us it is BooleanField
		'form': b_f.form, #the form within which this boolean field is bounded
		'help_text': b_f.help_text, #the help_text 
		'html_name': b_f.html_name, #the html_name attribute value 
		'id_for_label': b_f.id_for_label, #the id attribute of this html field 
		'is_hidden': b_f.is_hidden, #checks whether the field is hidden or not 
		'label': b_f.label, #the label of this field that is shown in the html or within <label></label> tag
		'name': b_f.name, #the html name attribute value  
	}
	
	#let's send these data 
	context={
		'data': dct,
	}
	return render(request, 'show.html', context)
	