from django import forms

class MyForm(forms.Form):
	#MyForm is a subclass of django form 
	#let's create the booleanfield filed
	b_field=forms.BooleanField(required=True, label='Click to agree on the terms and conditions', label_suffix='', initial=False, help_text='', error_messages={'required':'Please agree to our terms and conditions'}, disabled=False)