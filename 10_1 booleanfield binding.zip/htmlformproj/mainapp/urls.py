from django.urls import path

from . import views

#rest of the url after 'mainapp/' will be matched here
urlpatterns=[
	#calling the myview method
	path('',views.myview, name='mainurl'),
	path('show/', views.showview, name='showurl'),
]