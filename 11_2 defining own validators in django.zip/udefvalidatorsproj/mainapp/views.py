from django.shortcuts import render

from .myform import MyForm
# Create your views here.

def mainview(request):
	f=MyForm()
	#from mainview rendering home.html 
	return render(request, 'home.html', {'form': f})
	
def showview(request):
	rec_form=MyForm(request.POST)
	
	#let's send the data to another page for showing
	dct={
		'errors': rec_form['date_field'].errors,
		'data': rec_form['date_field'].data,
	}
	
	return render(request, 'show.html', {'data': dct})
