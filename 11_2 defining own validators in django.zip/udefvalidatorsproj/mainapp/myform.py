from django import forms

from .myvalidator import validate_date

class MyForm(forms.Form):
	date_field=forms.DateField(\
		required=True,\
		label="Input Date",\
		label_suffix=":",\
		help_text="enter a date of the form yyyy-mm-dd and date must be before 2000-01-01",\
		validators=[validate_date],\
		error_messages={'invalid_date':'The date must be before 2000-01-01'},\
	)