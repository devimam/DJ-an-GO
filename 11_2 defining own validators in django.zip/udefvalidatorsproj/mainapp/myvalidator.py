from django.core.exceptions import ValidationError

from datetime import date

def validate_date(value):
	cond_date=date(2000, 1, 1)
	
	if(value>=cond_date):
		raise ValidationError("Invalid Date Input",\
		code="invalid_date")