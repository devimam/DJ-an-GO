from django import forms

class MyForm(forms.Form):
	#MyForm is a subclass of forms.Form object 
	#let's set up the parameters of this field
	int_field=forms.IntegerField(\
		required=True,\
		label='Enter your age',\
		label_suffix=':',\
		initial=19,\
		localize=False,\
		help_text='Enter age between 18 to 40',\
		error_messages={'required':'Field can\'t be empty', 'invalid': 'Invalid Input',},\
		disabled=False,\
		max_value=40,\
		min_value=18,\
	)