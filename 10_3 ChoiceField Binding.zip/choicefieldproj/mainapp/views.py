from django.shortcuts import render

from .MyForm import MyForm
# Create your views here.

def mainview(request):
	f=MyForm()
	#rendering the home.html 
	#sending the form to the template 
	# to render the html 
	return render(request, 'home.html', {'form':f})
	
def showview(request):
	rec_form=MyForm(request.POST)
	
	#let's access the ChoiceField and it's properties
	#we can access ChoiceField from rec_form as a BoundField object
	b_f=rec_form['c_field'] #name of the field variable
	
	#let's access the properties
	dct={
		'auto_id': b_f.auto_id,
		'data': b_f.data,
		'errors': b_f.errors,
		'field': b_f.field,
		'form': b_f.form,
		'help_text': b_f.help_text,
		'html_name': b_f.html_name,
		'id_for_label': b_f.id_for_label,
		'is_hidden': b_f.is_hidden,
		'label': b_f.label,
		'name': b_f.name,
	}
	
	#let's send the data to the template page
	return render(request, 'show.html', {'data': dct})