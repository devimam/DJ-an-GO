from django import forms

class MyForm(forms.Form):
	#here MyForm is a subclass of forms.Form 
	#let's create a ChoiceField
	#choicefield has some parameters let's review them
	cnt=[
		('none', 'None'),
		('bd', 'Bangladesh'),
		('sg', 'Singapore'),
		('ot', 'Others'),
	]
	
	c_field=forms.ChoiceField(\
		required=True,\
		label='Enter Country',\
		label_suffix='>>>',\
		initial='none',\
		help_text='choose the country',\
		error_messages={'required':'Please enter your country info', 'invalid_choice': 'Please select a valid one'},\
		disabled=False,
		
		choices=cnt,
	)