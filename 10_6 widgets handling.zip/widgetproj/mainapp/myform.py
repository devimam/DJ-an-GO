from django import forms

class MyForm(forms.Form):
	#let's create a CharField having EmailInput widget
	email=forms.CharField(widget=forms.EmailInput)
	
	#let's create a CharField of type PasswordInput
	password = forms.CharField(widget=forms.PasswordInput)
	
	#let's create a CharField that will be hidden
	hidden=forms.CharField(widget=forms.HiddenInput)
	
	#let's create a CharField that will show a textarea
	#let's set some html attributes for that textarea
	address=forms.CharField(widget=forms.Textarea(attrs={'rows':20, 'cols': 100}))
	
	#let's create some Radio buttons using RadioSelect widget 
	#as it is a Select widget so we need to set the choices like ChoiceField
	chs={
		('m','Male'),
		('f', 'Female'),
	}
	
	#here we are using choicefield but instead of using dropdown box 
	# we will use radio buttons 
	# so here m will be the value of the user choose Male radio button 
	gender=forms.ChoiceField(widget=forms.RadioSelect, choices=chs)