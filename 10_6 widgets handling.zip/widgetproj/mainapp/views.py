from django.shortcuts import render

from .myform import MyForm
# Create your views here.

def mainview(request):
	f=MyForm()
	#from mainview rendering the home.html template
	#let's send this form to the template for rendering 
	return render(request, 'home.html',{'form': f})
	
def showview(request):
	f=MyForm(request.POST)
	
	#let's access these data in a dictionary
	dct={
		'email': f['email'].data,
		'password': f['password'].data,
		'hidden data': f['hidden'].data,
		'address data': f['address'].data,
		'gender': f['gender'].data,
	}
	
	#let's render these data to the template
	return render(request, 'show.html', {'data': dct})