from django.apps import AppConfig


class UrlconfappConfig(AppConfig):
    name = 'urlconfapp'
