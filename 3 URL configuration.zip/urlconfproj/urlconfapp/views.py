from django.shortcuts import render

# Create your views here.

def myview(request):
	context={
		'data' : 'from default view',
	}
	return render(request,'home.html', context)
	
def fixedview(request):
	context={
		'data' : 'from fixed url',
	}
	return render(request, 'home.html', context)
	
def kwargsview(request, key1):
	context={
		'data' : 'from kwargs url with key1 value = '+ key1,
	}
	return render(request, 'home.html', context)
	
def captureview(request, var1, var2, var3):
	context={
		'data' : 'from capture url var1 = '+str(var1)+' var2 = '+var2+' var3 = '+var3,
	}
	return render(request, 'home.html', context)
	