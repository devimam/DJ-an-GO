from django.urls import path

from . import views

urlpatterns=[
	#urls after 'urlconfapp/' goes here
	path('', views.myview, name='defview'),
	
	#fixed path
	path('fixedurl/', views.fixedview),
	
	#fixed path with keyword args
	path('kwargsurl/', views.kwargsview, {'key1':'value1'}),
	
	#capture values from url 
	path('captureurl/<int:var1>:<str:var2>/search/<slug:var3>/', views.captureview),
	
]