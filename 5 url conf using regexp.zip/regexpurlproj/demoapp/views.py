from django.shortcuts import render

# Create your views here.

def myview(request):
	context={
		'data':'Welcome to Home Page', #sending data 
	}
	return render(request, 'home.html', context)
	
def regexpview(request, regvar, key1):
	context={
		'data': 'Regexp Page regvar='+regvar+' key1='+key1,
	}
	return render(request, 'home.html', context)
	
