from django.urls import path, re_path

from . import views

#rest of the url after 'demoapp/' will be matched here
urlpatterns=[
	path('', views.myview, name='myview'), #calling myview
	
	#suppose we will capture email from the url using regexp
	#we will also send some keyword argument with the url
	re_path(r'^email/(?P<regvar>([A-Za-z][A-Za-z0-9_.]*@[A-Za-z0-9]{2,8}(\.[A-Za-z0-9]{2,6})+))/$', views.regexpview, {'key1':'value1'}, name='regexpurl'),
]