from django.urls import path

from . import views

#urls after 'mainapp/' will be matched here
urlpatterns=[
	path('', views.homeview, name='homeurl'), #calling homeview
]