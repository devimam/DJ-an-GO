from django.shortcuts import render

# Create your views here.


def homeview(request):
	#rendering home.html template
	return render(request, 'home.html')