function addreview(){
	var elm=document.getElementById('revboard');
	elm.innerHTML+="<br/><input type='text' placeholder='another review'>";
	//so when this function will be called
	//it will add another new review filed 
}